package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText;
    private EditText yearEditText;
    private Button calculateButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TODO: 1. Найти все элементы по их ID
        nameEditText = findViewById(R.id.nameEditText);
        yearEditText = findViewById(R.id.yearEditText);
        calculateButton = findViewById(R.id.calculateButton);
        resultTextView = findViewById(R.id.resultTextView);

        // TODO: 2. Установить обработчик клика на кнопку
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAge();
            }
        });
    }

    private void calculateAge() {
        // TODO: 3. Получить текст из EditText
        String name = nameEditText.getText().toString().trim();
        String yearString = yearEditText.getText().toString().trim();

        // TODO: 4. Проверить, не пустой ли ввод
        if (name.isEmpty()) {
            resultTextView.setTextColor(Color.BLACK);
            resultTextView.setText("введите ваше имя");
            return;
        }

        if (yearString.isEmpty()) {
            resultTextView.setTextColor(Color.BLACK);
            resultTextView.setText("введите год рождения");
            return;
        }

        try {
            // TODO: 5. Преобразовать введенный текст в число
            int birthYear = Integer.parseInt(yearString);

            // TODO: 6. Получить текущий год
            int currentYear = Calendar.getInstance().get(Calendar.YEAR);

            // TODO: 7. Рассчитать возраст
            int age = currentYear - birthYear;

            // Задание 1: Добавьте проверку на корректность ввода (год не может быть больше текущего)
            if (age < 0) {
                resultTextView.setTextColor(Color.RED);
                resultTextView.setText("год рождения не может быть в будущем!");
                return;
            }

            // Задание 3: Измените цвет результата в зависимости от возраста:
            // - До 18 лет - синий цвет
            // - От 18 до 60 - зеленый цвет
            // - Старше 60 - красный цвет
            if (age < 18) {
                resultTextView.setTextColor(Color.BLUE);
            } else if (age <= 60) {
                resultTextView.setTextColor(Color.GREEN);
            } else {
                resultTextView.setTextColor(Color.RED);
            }

            // TODO: 8. Отобразить результат в TextView
            // Задание 2: Добавьте второй EditText для ввода имени и выводите сообщение:
            // "Привет, [имя]! Ваш возраст: [возраст] лет"
            resultTextView.setText("привет, " + name + "! Ваш возраст: " + age + " лет");

        } catch (NumberFormatException e) {
            resultTextView.setTextColor(Color.RED);
            resultTextView.setText("введите корректный год");
        }
    }
}